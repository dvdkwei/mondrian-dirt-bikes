create view RATE_TMP as
select avrg, ts from (
    select to_number(avg(EX_RATE)) avrg, ts from (
        select EX_RATE, to_timestamp(RATE_DATE) ts from wi2_acu008_EXCHANGE_RATE
    )
    group by ts
)
/

