create view DATE_JOINS as
select distinct dk_bestdatum as dates from DB_SCHULTZ.wi2_erp10v3_dokkopf
order by dates
/

