create view JOINS as
select DB_SCHULTZ.wi2_oltp_DOKKOPF.G3_BESTDATUM as ORDER_DATE,
        DB_SCHULTZ.wi2_oltp_DOKKOPF.G3_KUNDE as CUSTOMER,
        DB_SCHULTZ.wi2_oltp_kundenstamm.G3_KUNDEBESCHR as C_DESC,
        DB_SCHULTZ.wi2_oltp_DOKPOS.DP_PRODUKT as PRODUCT,
        DB_SCHULTZ.wi2_oltp_materialstamm.G3_PRODUKTBESCHR as PRODUCT_DESC,
        DB_SCHULTZ.wi2_oltp_materialstamm.G3_PRODKATEGORIE as P_CATEGORY,
        DB_SCHULTZ.wi2_oltp_materialstamm.G3_DIVISION as DIVISION,
        DB_SCHULTZ.wi2_oltp_kundenstamm.G3_VERTRIEBSORG as ORGANISATION,
        DB_SCHULTZ.wi2_oltp_kundenstamm.G3_STADT as City,
        DB_SCHULTZ.wi2_oltp_kundenstamm.G3_LAND as Country,
        DB_SCHULTZ.wi2_oltp_DOKPOS.G3_UMSATZUSD as REVENUE,
        DB_SCHULTZ.wi2_oltp_DOKPOS.G3_RABATTUSD as DISCOUNT,
        DB_SCHULTZ.wi2_oltp_DOKPOS.G3_HERSTELLKOSTENUSD as COGS,
        DB_SCHULTZ.wi2_oltp_DOKPOS.G3_VERKAUFSMENGE as SALES_QUANTITY
    from DB_SCHULTZ.wi2_oltp_DOKKOPF
    join DB_SCHULTZ.wi2_oltp_DOKPOS on G3_BELEGNR = DP_BELEGNO
    join DB_SCHULTZ.wi2_oltp_materialstamm on DP_PRODUKT = G3_PRODUKT
    join DB_SCHULTZ.wi2_oltp_kundenstamm on
        DB_SCHULTZ.wi2_oltp_kundenstamm.G3_KUNDE =
        DB_SCHULTZ.wi2_oltp_DOKKOPF.G3_KUNDE
/

